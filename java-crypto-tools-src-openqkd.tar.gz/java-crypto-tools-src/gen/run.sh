#java -cp target/BouncyCastleTest-0.0.1-SNAPSHOT.jar:lib/* chapter10.PKCS12Example
#java -Djava.util.logging.config.file=logging.properties -cp target/BouncyCastleTest-0.0.1-SNAPSHOT.jar:lib/* chapter14.BasicTLSExample
java -Djava.util.logging.config.file=logging.properties -cp target/BouncyCastleTest-0.0.1-SNAPSHOT.jar:lib/* chapter15.Frodo
